<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    public $user;


    /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct(); 
	   $this->load->model('UserModel');
	   $this->load->database();
	   $this->load->helper('form');
    }


    public function create()
    {

		// /*load registration view form*/
		// $this->load->view('insert');
	
		/*Check submit button */
		if($this->input->post('save'))
		{
			$name=$this->input->post('name');
			$email=$this->input->post('email');
			$mobile_no=$this->input->post('mobile_no');
			$date=$this->input->post('date');
			$refferal_user=$this->input->post('refferal_user');
			$this->UserModel->saverecords($name,$email,$mobile_no,$date,$refferal_user);	
			$this->load->view('login');
			}
	}
	
	public function index()
	{
		$this->load->view('login');
	}

	public function login() {

		$name=$this->input->post('name');
		$password=$this->input->post('password');
		$userModel = $this->UserModel->auth($name,$password);
		$result = $userModel->result();
		if($result){
			if($result[0]->name == $name && $result[0]->password == $password && $result[0]->super_access == 'U') {
				$user = $result[0]->id;
				if($result[0]->url) {
					$data['url'] = 1;	
				} else {
					$data['url'] = 0;
				}
				$data['user_id'] = $user;
				$this->load->view('user_dashboard',$data);
			} else if($result[0]->name == $name && $result[0]->password == $password && $result[0]->super_access == 'A'){
				$data['userList'] = $this->UserModel->getAllUsers();
				$this->load->view('admin_dashboard',$data);
			} else {
				$this->load->view('login');
			};
		} else {
			$this->load->view('login');
		}
	}

	public function register()
	{
		$data['userList'] = $this->UserModel->getAllUsers();
		$this->load->view('register',$data);
	}


	public function upload_file()
    {       
		$user_id = $this->input->post('user_id');
		$url =[];
        $this->load->library('upload');

        $files = $_FILES;
        $cpt = count($_FILES['userfile']['name']);
        for($i=0; $i<$cpt; $i++)
        {   $url[] =  $files['userfile']['name'][$i];
            $_FILES['userfile']['name']= $files['userfile']['name'][$i];
            $_FILES['userfile']['type']= $files['userfile']['type'][$i];
            $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
            $_FILES['userfile']['error']= $files['userfile']['error'][$i];
            $_FILES['userfile']['size']= $files['userfile']['size'][$i];    

            $this->upload->initialize($this->set_upload_options());
            $this->upload->do_upload();
		}
		$urls = implode(', ', $url);
		$this->UserModel->update_image($user_id,$urls);
		if($urls) {
			$data['url'] = 1;	
		} else {
			$data['url'] = 0;
		}
		$this->load->view('user_dashboard',$data);
		
    }

    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '0';
        $config['overwrite']     = FALSE;

        return $config;
    }

	public function ajax_post()
    {   
		$user_id=$this->input->post('user_id');
		$this->UserModel->notification($user_id);	
		echo "Records Saved Successfully";
	}
}
