<?php


class UserModel extends CI_Model{

	/*Insert*/
	public function saverecords($name,$email,$mobile_no,$date,$refferal_user)
	{
		$username = strtolower($name);
		$query="INSERT INTO `user` (`name`, `email`, `mobile_no`, `date`, `referral_user`, `user_status`,`status`) VALUES ('$username', '$email', '$mobile_no', '$date', '$refferal_user', 'P','A')";
		$this->db->query($query);
	}

	public function getAllUsers()
	{
		$query = $this->db->query("SELECT * FROM user where status='A' and super_access='U'" );
		return $query->result();
	}

	public function getAllUsersNotification() {
		$query = $this->db->query("SELECT * FROM user where status='A' and admin_view_status='1'");
		return $query->num_rows();
	}
	public function update_user($id) 
    {
        $data=array(
            'name' => $this->input->post('name'),
			'email'=> $this->input->post('email'),
			'mobile_no' => $this->input->post('mobile_no'),
			'date'=> $this->input->post('date'),
			'referral_user' => $this->input->post('refferal_user'),
			'user_status'=> $this->input->post('user_status'),
			'password' => $this->input->post('password')
		);
        if($id==0){
            return $this->db->insert('user',$data);
        }else{
            $this->db->where('id',$id);
            return $this->db->update('user',$data);
        }        
	}
	
	public function auth($name,$password){
		$query = "SELECT * FROM user WHERE name = '".$name."' and password ='".$password."' ";
		$row = $this->db->query($query);
		return $row;
	}

	public function update_image($user_id,$urls) 
    {
		
        $data=array(
			'url' => $urls,
			'admin_view_status' => 1
		);
        if($user_id){
            $this->db->where('id',$user_id);
            return $this->db->update('user',$data);
        }     
	}

	public function notification($user_id) 
    {
		
        $data=array(
			'id' => $user_id,
			'admin_view_status' => '0'
		);
        if($user_id){
            $this->db->where('id',$user_id);
            return $this->db->update('user',$data);
        }     
	}

	public function delete($user_id) 
    {
        $data=array(
			'id' => $user_id,
			'status' => 'D'
		);
        if($user_id){
            $this->db->where('id',$user_id);
            return $this->db->update('user',$data);
        }     
	}

}
?>