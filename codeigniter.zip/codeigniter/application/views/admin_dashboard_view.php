<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
      <a href="<?php echo base_url('index.php/user')?>">Log out</a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="<?php echo base_url();?>assets/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">AdminLTE 3</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo base_url();?>assets/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div>
      </div>
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo base_url('index.php/AdminDashboard')?>" class="nav-link">
              <i class="fas fa-circle nav-icon"></i>
              <p>User List</p>
            </a>
          </li>

      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Info</h1>
          </div>
          <div class="col-sm-6">
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row mb-2">
                <div class="col-3">
                    <h4>NAME </h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $user->name;?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>EMAIL ID </h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $user->email;?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>MOBILE NUMBER </h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $user->mobile_no;?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>DATE</h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $user->date;?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>Refeeral user</h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $refeeral_user?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>USER STATUS</h4>
                </div>
                <div class="col-9">
                    <h4><?php echo $user->user_status;?></h4>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>Image1</h4>
                </div>
                <div class="col-9">
                    <?php $url = explode(',',$user->url); ?>
                    <?php if($user->url) { ?>
                        <img src="<?php echo base_url();?>uploads/<?php echo str_replace(' ', '', $url[0]) ?>" height="100px"/>
                    <?php } ?>  
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-3">
                    <h4>Image2</h4>
                </div>
                <div class="col-9">
                    <?php $url = explode(',',$user->url); ?>
                    <?php if($user->url) { ?>
                        <img src="<?php echo base_url();?>uploads/<?php echo str_replace(' ', '', $url[1]) ?>" height="100px"/>
                    <?php } ?>
                </div>
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer no-print">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url();?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>
</body>
</html>
